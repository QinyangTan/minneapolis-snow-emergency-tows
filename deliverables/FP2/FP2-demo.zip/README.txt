FP2 DEMO

Requires Node.js 20 or newer. No npm installation needed.
Windows: double-click start-demo.cmd.
Other systems: run node demo-server.mjs in this folder.
Open http://127.0.0.1:4175/fp2/
Keep the server window open; Ctrl+C stops it.

All data is bundled. Optional web fonts fall back to local fonts offline.
Do not double-click site/fp2/index.html; use the local server.
